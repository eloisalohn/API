import React from 'react';
import Home from './componentes/Home';
import Perfil from './componentes/Perfil';
import Login from './componentes/Login';
import Cadastro from './componentes/Cadastro';
import Configuracoes from './componentes/Configuracoes';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css'


function App() {

  return (
    <>
   
   <Router>
    <Routes>
      <Route path="/login" element={<Login/>} />
      <Route path="/cadastro" element={<Cadastro />} />
      <Route path="/home" element={<Home />} />
      <Route path="/perfil" element={<Perfil />} />
      <Route path="/configuracoes" element={<Configuracoes />} />
    </Routes>
   </Router>

    </>
  )
}

export default App
