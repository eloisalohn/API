import { useNavigate } from 'react-router-dom';

export default function Cadastro(){
    return(
        <>
        <div className="telaLog">
        <div className="log">
        <h1>Talent ShowCase</h1>
        <button>Entrar com Google</button>
        <br /><br />
        <form className="senhas">
            <label>Email:</label>
        <input type="text" />
            <label>Nome de usuário:</label>
        <input type="text" />
            <label>Senha:</label>
        <input type="password" />
            <label>Confirme a senha:</label>
        <input type="password" />
        </form>
        <br /><br />
        <button>Cadastrar</button>
        <br /><br />
        <a href="">Já tem conta? Faça Login!</a>
            </div>
        </div>
   </>
)
}