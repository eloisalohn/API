import { useNavigate } from 'react-router-dom';

export default function Perfil(){
    return(
        <>
       
       <div class="conta">
        <header>
        <h1>Talent ShowCase</h1>

<div class="cabecalho">
<button class="botonP"><a href="/Pesquisa.jsx">Pesquisar</a></button>
</div>
        </header>
        </div> 
        <div class="interno">
            <img src="user.jpg" class="imguser"/>
            <div class="dentro">
                <h1>Olá, #######!</h1><br />
            <button>Configurações</button>
            <br />
            <button>Saldo</button>
            </div>
        </div>
        <div class="fundo_">
<h2>Não há videos postados</h2>
</div>
        </>
    )
}