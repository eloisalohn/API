import { useNavigate } from 'react-router-dom';

export default function Login(){
    return(
        <>
        <div className="telaLog">
        <div className="log">
        <h1>Talent ShowCase</h1>
        <button>Entrar com Google</button>
        <br /><br />
        <form className="senhas">
            <label>Email ou Nome de usuário:</label>
        <input type="text" />
            <label>Senha:</label>
        <input type="password" />
        <a href="">Esqueceu a senha?</a>
        </form>
        <br /><br />
        <button>Entrar</button>
        <br /><br />
        <a href="">Não tem cadastro? Cadastre-se!</a>
            </div>
        </div>
   </>
)
}