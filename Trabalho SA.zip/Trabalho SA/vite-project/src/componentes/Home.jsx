import { useNavigate } from 'react-router-dom';

export default function Home() {

const Navto = useNavigate();

    return (
        <>
        <div class="body">
     <header>
     <h1>Publicações</h1>

<div class="cabecalho">
<button class="botonP"><a href="/Pesquisa.jsx">Pesquisar</a></button>
</div>

<div>
    <nav class="perfil">
        <ul>
            <li>Perfil</li>
            <li>Configurações</li>
            <li>Login</li>
        </ul>
    </nav>
</div>

     </header>

<div class="fundo">
<h2>Não há videos postados</h2>
</div>
</div>

        </>
    )
}